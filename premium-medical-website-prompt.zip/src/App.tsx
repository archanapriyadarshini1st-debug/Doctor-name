import { useEffect } from "react";
import { ScrollTrigger } from "@/lib/motion";
import { Navbar } from "@/components/Navbar";
import { Cursor } from "@/components/Cursor";
import { Hero } from "@/components/Hero";
import { TrustStrip } from "@/components/TrustStrip";
import { DoctorProfile } from "@/components/DoctorProfile";
import { SpecialtyExplorer } from "@/components/SpecialtyExplorer";
import { PatientJourney } from "@/components/PatientJourney";
import { Testimonials } from "@/components/Testimonials";
import { ClinicGallery } from "@/components/ClinicGallery";
import { Location } from "@/components/Location";
import { AppointmentForm } from "@/components/AppointmentForm";
import { FAQ } from "@/components/FAQ";
import { FinalCTA } from "@/components/FinalCTA";
import { Footer } from "@/components/Footer";

export default function App() {
  useEffect(() => {
    // Mark JS-enabled so pre-reveal opacity only applies when GSAP will run.
    document.documentElement.classList.add("js");
    // Refresh triggers once fonts/images settle to avoid mis-measured pins.
    const refresh = () => ScrollTrigger.refresh();
    document.fonts?.ready.then(refresh);
    window.addEventListener("load", refresh);
    return () => window.removeEventListener("load", refresh);
  }, []);

  return (
    <>
      <Cursor />
      <Navbar />
      <main id="main">
        <Hero />
        <TrustStrip />
        <DoctorProfile />
        <SpecialtyExplorer />
        <PatientJourney />
        <Testimonials />
        <ClinicGallery />
        <Location />
        <AppointmentForm />
        <FAQ />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
