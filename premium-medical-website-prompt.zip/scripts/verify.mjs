// Browser verification: console errors, overflow, screenshots at key viewports.
import { chromium } from "playwright";
import { createServer } from "http";
import { readFileSync } from "fs";

const html = readFileSync("dist/index.html");
const server = createServer((_, res) => {
  res.writeHead(200, { "Content-Type": "text/html" });
  res.end(html);
}).listen(4173);

const viewports = [
  { name: "mobile-360", width: 360, height: 780 },
  { name: "mobile-390", width: 390, height: 844 },
  { name: "tablet-820", width: 820, height: 1180 },
  { name: "laptop-1280", width: 1280, height: 800 },
  { name: "desktop-1440", width: 1440, height: 900 },
  { name: "wide-1920", width: 1920, height: 1080 },
];

const browser = await chromium.launch();
const wantFull = process.argv.includes("--full");
const only = process.argv.find((a) => a.startsWith("--only="))?.split("=")[1];

for (const vp of viewports) {
  if (only && vp.name !== only) continue;
  const ctx = await browser.newContext({ viewport: { width: vp.width, height: vp.height }, deviceScaleFactor: 1 });
  const page = await ctx.newPage();
  const errors = [];
  page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://localhost:4173/", { waitUntil: "networkidle" });
  await page.waitForTimeout(3200); // let intro finish

  const overflow = await page.evaluate(() => {
    const docW = document.documentElement.clientWidth;
    const bad = [];
    document.querySelectorAll("body *").forEach((el) => {
      const r = el.getBoundingClientRect();
      if (r.width > 0 && (r.right > docW + 2 || r.left < -2) && getComputedStyle(el).position !== "fixed") {
        const inHScroll = el.closest(".no-scrollbar, [data-cursor='Drag']");
        if (!inHScroll) bad.push(`${el.tagName.toLowerCase()}.${[...el.classList].slice(0, 3).join(".")} right=${Math.round(r.right)} left=${Math.round(r.left)}`);
      }
    });
    return { scrollW: document.documentElement.scrollWidth, docW, bad: bad.slice(0, 8) };
  });

  await page.screenshot({ path: `scripts/shots/${vp.name}-hero.png` });
  if (wantFull) {
    // scroll through to trigger reveals, then full page
    await page.evaluate(async () => {
      const h = document.documentElement.scrollHeight;
      for (let y = 0; y < h; y += 400) {
        window.scrollTo({ top: y, behavior: "instant" });
        await new Promise((r) => setTimeout(r, 90));
      }
      window.scrollTo({ top: 0, behavior: "instant" });
    });
    await page.waitForTimeout(800);
    await page.screenshot({ path: `scripts/shots/${vp.name}-full.png`, fullPage: true });
  }
  console.log(`${vp.name}: errors=${errors.length} scrollW=${overflow.scrollW}/${overflow.docW} overflow=${overflow.bad.length ? JSON.stringify(overflow.bad) : "none"}`);
  errors.slice(0, 5).forEach((e) => console.log("   ERR:", e.slice(0, 200)));
  await ctx.close();
}
await browser.close();
server.close();
