import { chromium } from "playwright";
import { createServer } from "http";
import { readFileSync } from "fs";

const html = readFileSync("dist/index.html");
const server = createServer((_, res) => { res.writeHead(200, { "Content-Type": "text/html" }); res.end(html); }).listen(4174);
const browser = await chromium.launch();
const log = (...a) => console.log(...a);

// ---- Desktop: form, FAQ, specialties, keyboard ----
{
  const page = await (await browser.newContext({ viewport: { width: 1440, height: 900 } })).newPage();
  const errors = []; page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://localhost:4174/", { waitUntil: "networkidle" });
  await page.waitForTimeout(2500);

  // Specialties hover swaps image
  await page.locator("#specialties").scrollIntoViewIfNeeded();
  await page.waitForTimeout(600);
  await page.hover("#specialties button:has-text('Cardiac diagnostics')");
  await page.waitForTimeout(1000);
  const live = await page.locator("#specialties [aria-live]").innerText();
  log("specialties live text:", live.split("\n")[0]);
  await page.screenshot({ path: "scripts/shots/specialties-hover.png" });

  // Form: submit empty → errors, then fill → success
  await page.locator("#appointment").scrollIntoViewIfNeeded();
  await page.waitForTimeout(800);
  await page.click("#appointment button[type=submit]");
  const alerts = await page.locator("#appointment [role=alert]").count();
  log("validation alerts after empty submit:", alerts);
  const focused = await page.evaluate(() => document.activeElement?.getAttribute("name"));
  log("focus moved to first invalid field:", focused);
  await page.fill("input[name=name]", "Test Patient");
  await page.fill("input[name=email]", "test@example.com");
  const d = new Date(); d.setDate(d.getDate() + 3);
  await page.fill("input[name=date]", d.toISOString().split("T")[0]);
  await page.selectOption("select[name=time]", { index: 1 });
  await page.selectOption("select[name=reason]", { index: 1 });
  await page.click("#appointment button[type=submit]");
  const busy = await page.locator("#appointment button[aria-busy=true]").count();
  log("loading state shown:", busy === 1);
  await page.waitForTimeout(1600);
  const successText = await page.locator("#appointment [aria-live=polite]").innerText().catch(() => "none");
  log("success state:", successText.includes("Demo mode") ? "ok (demo disclaimer present)" : successText.slice(0, 80));
  await page.screenshot({ path: "scripts/shots/form-success.png" });

  // FAQ accordion
  await page.locator("#faq").scrollIntoViewIfNeeded();
  const q2 = page.locator("#faq button").nth(1);
  await q2.click();
  await page.waitForTimeout(700);
  log("faq item 2 expanded:", await q2.getAttribute("aria-expanded"));
  log("faq item 1 collapsed:", await page.locator("#faq button").nth(0).getAttribute("aria-expanded"));

  // Keyboard: tab from top hits skip link then logo
  await page.evaluate(() => { window.scrollTo({ top: 0, behavior: "instant" }); (document.activeElement).blur(); });
  await page.keyboard.press("Tab");
  const first = await page.evaluate(() => document.activeElement?.textContent?.trim());
  await page.keyboard.press("Tab");
  const second = await page.evaluate(() => document.activeElement?.getAttribute("aria-label") || document.activeElement?.textContent?.trim());
  log("tab order:", first, "→", second);
  log("desktop pageerrors:", errors.length);
}

// ---- Mobile: menu open/close, touch specialties ----
{
  const page = await (await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true, isMobile: true })).newPage();
  const errors = []; page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://localhost:4174/", { waitUntil: "networkidle" });
  await page.waitForTimeout(2500);
  await page.click("button[aria-controls=mobile-menu]");
  await page.waitForTimeout(1000);
  log("menu open aria-expanded:", await page.locator("button[aria-controls=mobile-menu]").getAttribute("aria-expanded"));
  await page.screenshot({ path: "scripts/shots/mobile-menu.png" });
  await page.keyboard.press("Escape");
  await page.waitForTimeout(800);
  log("menu closed via Escape:", await page.locator("button[aria-controls=mobile-menu]").getAttribute("aria-expanded"));
  log("cursor overlay absent on touch:", (await page.locator("[data-cursor-root]").count()) === 0);
  await page.locator("#specialties").scrollIntoViewIfNeeded();
  await page.locator("#specialties button:visible:has-text('Long-term heart care')").click();
  await page.waitForTimeout(700);
  log("mobile specialty 4 expanded:", await page.locator("#specialties button:visible:has-text('Long-term heart care')").getAttribute("aria-expanded"));
  log("mobile pageerrors:", errors.length);
}

// ---- Reduced motion: everything visible without animation ----
{
  const page = await (await browser.newContext({ viewport: { width: 1280, height: 800 }, reducedMotion: "reduce" })).newPage();
  await page.goto("http://localhost:4174/", { waitUntil: "networkidle" });
  await page.waitForTimeout(600);
  const hidden = await page.evaluate(() => {
    const els = [...document.querySelectorAll("h1, h2, [data-reveal]")];
    return els.filter((el) => { const s = getComputedStyle(el); return s.opacity === "0" || s.visibility === "hidden"; }).length;
  });
  log("reduced-motion hidden headings/reveals at load:", hidden);
  await page.screenshot({ path: "scripts/shots/reduced-motion.png" });
}

await browser.close(); server.close();
